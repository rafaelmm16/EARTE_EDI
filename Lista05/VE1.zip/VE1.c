#include <stdio.h>
#include <stdlib.h>

#include "VE1.h"

struct ve1 {
    int capacidade; //Tamanho do array F
    int n;          //Posição do útimo elemento (também pode ser usado para determinar o #elementos)
    int *P;         //Array para armazenar os elementos na estrutura
};

VE1 *criaVE1(int capacidade) {
    /*Verifique se o valor em capacidade é válido */
    /*Se for, inicialize n com -1 (indicando que a estrutura está vazia) */
    /*Aloque o array 'P' e retorne o ponteiro da estrutura */


    return NULL;
}

void liberaVE1(VE1 *ve) {
    /* Faz a desalocação de memória */
}

void adicionaVE1(VE1 *ve, int v) {
    /* Adiciona um elemento no fim do vetor */
    /* Lembre-se de verificar se há espaço para adicionar o elemento */
    /* Complexidade: O(???)  */              


}

void removeVE1(VE1 *ve) {
    /* Retira o ultimo elemento*/
    /* Complexidade: O(???)  */

}

int obtemElementoVE1(VE1 *ve){
    /*Retorna o elemento ultimo */
    /* Complexidade: O(???)  */

    return - 1;
}

int vazioVE1(VE1 *ve) {
    /* Verifica se a estrutura possui algum elemento ou está vazia */
    /* Complexidade: O(???)  */


    return -1;
}

int cheioVE1(VE1 *ve) {
    /* Verifica se a estrutura está cheia */
    /* Complexidade: O(???)  */


    return -1;
}

int tamanhoVE1(VE1 *ve) {
    /* Retorna o número de elementos que a estrutura armazena */
    /* Complexidade: O(???)  */

    return -1;
}
