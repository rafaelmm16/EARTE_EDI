#ifndef EP2_POSFIXA_H
#define EP2_POSFIXA_H

#include "Objeto.h"
#include "Fila.h"

Fila *infixaParaPosfixa(Fila *infixa);

void imprimePosFixa(Fila *posfixa);

#endif