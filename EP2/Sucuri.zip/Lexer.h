#ifndef EP2_LEXER_H
#define EP2_LEXER_H

#include "Fila.h"

Fila *criaFilaObjetos(char* str);

#endif