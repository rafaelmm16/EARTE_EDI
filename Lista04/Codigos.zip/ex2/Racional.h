#ifndef RACIONAL_H
#define RACIONAL_H

typedef enum {
    false,
    true
} bool;

typedef struct racional Racional;

/* Adicione (apenas) os protótipos das funções */


#endif