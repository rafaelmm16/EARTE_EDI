#include <stdio.h>
#include <stdlib.h>

#include "Racional.h"

struct racional {
    long num;
    long den;
};

/* Adicione a implementação de cada função nesse arquivo */
