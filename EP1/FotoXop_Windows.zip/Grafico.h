#ifndef GRAFICO_H
#define GRAFICO_H

#include "Imagem.h"

void inicializa(int *argc, char *argv[], Imagem *imagem);

#endif /* GRAFICO_H */